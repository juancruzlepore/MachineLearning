hald = importdata('hald.dat');
corrcoef(hald)
