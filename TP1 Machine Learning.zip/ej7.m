%{

	7.a y 7.b/c)
	Los graficos fueron realizados via interfaz grafica.

	7.d)
	R^2 = 0.9988 para el polinomio cúbico
	R^2 = 0.9987 para el polinomio cuadrático

	Esto nos dice que el polinomio cúbico se ajusta mejor a los datos dados.

	7.e)
	El modelo cúbico predijo 277 millones

	El modelo cuadrático predijo 275 millones

	Por lo tanto, el modelo cúbico estuvo más cerca de la respuesta correcta.

}